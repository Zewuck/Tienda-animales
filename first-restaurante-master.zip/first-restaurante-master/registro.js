import {Router} from 'express'
import {engine} from 'express-handlebars'
import moduleName from 'express-myconnection'
import mysql from 'mysql'
import session from 'express-session'
import bodyparser from 'body-parser'

const express = require("express");



const router = Router()

module.exports(router)